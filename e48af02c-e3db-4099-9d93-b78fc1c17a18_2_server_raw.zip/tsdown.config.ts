import { defineConfig } from 'tsdown';

export default defineConfig({
    outDir: 'dist',
    format: 'esm',
    platform: 'node',
    target: 'node24',
    fixedExtension: true,
    clean: true,
    minify: true,
    sourcemap: false,
    noExternal: [/.*/],
    inlineOnly: false,
    outputOptions: output => ({
        ...output,
        codeSplitting: false,
    }),
});
