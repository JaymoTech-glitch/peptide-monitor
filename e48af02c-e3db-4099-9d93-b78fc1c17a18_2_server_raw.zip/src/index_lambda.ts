import { handle, streamHandle } from 'hono/aws-lambda'
import './core/env.core.js'
import app from './core/app.core.js'

export const handler = process.env.LAMBDA_INVOKE_MODE === 'STREAM' ? streamHandle(app) : handle(app)
