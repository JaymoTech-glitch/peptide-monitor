import { serve } from '@hono/node-server';
import './core/env.core.js';
import app from './core/app.core.js';

const PORT = Number.parseInt(process.env.PORT) || 3030;
serve({ fetch: app.fetch, port: PORT }, info => console.log(`Server is running on http://localhost:${info.port}`));
