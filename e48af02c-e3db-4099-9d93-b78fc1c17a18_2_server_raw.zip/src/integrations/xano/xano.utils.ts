import { XanoNodeClient } from '@xano/js-sdk';
import { HTTPException } from 'hono/http-exception';

export function getXanoClient(connection: ConnectionConfig): XanoNodeClient {
    if (!connection) throw new Error('Xano connection is required');
    return new XanoNodeClient({
        instanceBaseUrl: connection?.customDomain || `https://${connection?.instanceBaseDomain}`,
        dataSource: connection?.xDataSource,
        customAxiosRequestConfig: {
            headers: {
                ...(connection?.globalHeaders || {}),
                'X-Branch': connection.xBranch,
            },
        },
    });
}

export function buildPath(template: string, pathParams: Record<string, any> = {}): string {
    let path = template;
    for (const [key, value] of Object.entries(pathParams)) {
        path = path.replace(`{${key}}`, encodeURIComponent(String(value)));
    }
    return path;
}

export function enrichXanoError(error: any): never {
    const response = error.getResponse?.();
    const status = response?.getStatusCode?.() || 500;
    const data = response?.getBody?.();
    const message = data?.message || data?.payload?.message || error.message;

    throw new HTTPException(status, { message, cause: { status, data } });
}
