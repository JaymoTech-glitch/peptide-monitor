import { Resend } from 'resend';
import { transformFileAttachments } from '../utils.ts';

global.registerAction('resend/emails-send', async ({ args }: ActionParams, context: ActionContext) => {
    const resend = new Resend(context.connection?.apiKey);

    if (args.attachments) {
        args.attachments = await transformFileAttachments(args.attachments, 'content');
    }
    const { data, error } = await resend.emails.send({
        from: args.from,
        to: args.to,
        subject: args.subject,
        html: args.html,
        text: args.text,
        replyTo: args.replyTo,
        bcc: args.bcc,
        cc: args.cc,
        tags: args.tags,
        attachments: args.attachments,
    });

    if (error) throw error;
    return data;
});
