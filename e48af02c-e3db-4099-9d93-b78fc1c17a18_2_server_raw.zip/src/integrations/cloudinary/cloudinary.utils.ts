import { v2 as cloudinary } from 'cloudinary';

export function configureCloudinary(connection: ConnectionConfig) {
    cloudinary.config({
        cloud_name: connection?.cloudName,
        api_key: connection?.apiKey,
        api_secret: connection?.apiSecret,
    });
    return cloudinary;
}
