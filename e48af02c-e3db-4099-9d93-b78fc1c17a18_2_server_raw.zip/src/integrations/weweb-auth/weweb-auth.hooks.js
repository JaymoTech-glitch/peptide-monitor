import betterAuth from './better-auth.js';

global.registerHook('auth-refresh', 'integration:weweb-auth', async (c) => {
    const session = await betterAuth.api.getSession({ headers: c.req.raw.headers });
    if (!session) {
        c.set('user', null);
        c.set('session', null);
    } else {
        c.set('user', session.user);
        c.set('session', session.session);
    }
});
