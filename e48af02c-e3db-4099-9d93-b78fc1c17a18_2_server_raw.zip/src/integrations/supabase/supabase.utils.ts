import { createClient } from '@supabase/supabase-js';

export function processSupabaseObjectData(
    actionData: Record<string, unknown> = {},
    tableLinkData: Record<string, unknown> = {}
): Record<string, unknown> {
    const data: Record<string, unknown> = {};

    for (const [key, value] of Object.entries(tableLinkData)) {
        data[key] = value;
    }

    for (const [key, value] of Object.entries(actionData)) {
        if (value !== undefined && value !== null && value !== '') {
            data[key] = value;
        } else if (!(key in data)) {
            data[key] = value;
        }
    }

    return data;
}

export function getSupabaseClient(connection: ConnectionConfig) {
    const url = connection?.customDomain || `https://${connection?.branchRef || connection?.projectRef}.supabase.co`;
    return createClient(url, connection?.secretKey);
}

export function buildSelectString(columns: any, joinTypes: any = {}): string {
    if (!columns || columns === '*') return '*';
    if (Array.isArray(columns)) return columns.join(', ') || '*';

    const rootCols: string[] = [];
    const joinFragments: string[] = [];

    for (const [key, val] of Object.entries(columns)) {
        if (key === '*') { rootCols.push('*'); continue; }

        if (val === true) {
            rootCols.push(key);
        } else if (typeof val === 'object' && val !== null) {
            const nestedVal = (val as any).$value || val;
            let colStr = '*';
            if (nestedVal && typeof nestedVal === 'object') {
                const nestedCols = Object.keys(nestedVal).filter(k => k !== '$alias' && k !== '$value');
                colStr = nestedCols.length ? nestedCols.join(', ') : '*';
            }

            const tableName = key.includes('__') ? key.split('__')[0] : key;
            const hint = joinTypes[key] === 'inner' ? '!inner' : '';
            joinFragments.push(`${tableName}${hint}(${colStr})`);
        }
    }

    return [...rootCols, ...joinFragments].join(', ') || '*';
}

export function applyFilters(query: any, filters: any) {
    if (!filters?.length) return query;

    for (const filter of filters) {
        if (!filter.isEnabled) continue;

        const { fn, column, value, operator, options } = filter;

        if (fn === 'match') {
            if (value) query = query.match(value);
        } else if (fn === 'or') {
            if (value) query = query.or(value);
        } else if (fn === 'not' && column && operator && value !== undefined) {
            query = query.not(column, operator, value);
        } else if (fn === 'filter' && column && operator && value !== undefined) {
            query = query.filter(column, operator, value);
        } else if (fn === 'textSearch' && column && value) {
            query = query.textSearch(column, value, { config: options?.config || 'english' });
        } else if (fn === 'in' && column && Array.isArray(value) && value.length) {
            query = query.in(column, value);
        } else if (fn === 'is' && column && value !== undefined) {
            query = query.is(column, value);
        } else if (column && value !== undefined && value !== '') {
            query = query[fn](column, value);
        }
    }

    return query;
}


const POSTGREST_OP_OVERRIDES: Record<string, string> = {
    contains: 'cs', containedBy: 'cd', overlaps: 'ov', textSearch: 'fts',
};

function conditionToPostgrest(c: any): string | null {
    const { operator, value } = c;
    const column = Array.isArray(c.field) ? c.field.join('.') : c.field;
    if (!column || !operator || value === undefined || value === '') return null;
    if (c.isEmptyIgnored && value === null) return null;

    const op = POSTGREST_OP_OVERRIDES[operator] || operator;

    if (operator === 'in') {
        const vals = Array.isArray(value) ? value.join(',') : String(value);
        return `${column}.in.(${vals})`;
    }
    if (operator === 'contains' || operator === 'containedBy' || operator === 'overlaps') {
        const vals = Array.isArray(value) ? value.join(',') : String(value);
        return `${column}.${op}.{${vals}}`;
    }
    if (operator === 'textSearch') {
        return `${column}.fts.${value}`;
    }

    return `${column}.${op}.${value}`;
}

function groupToPostgrest(group: any): string {
    const parts = (group.conditions || [])
        .map((c: any) => c.link ? groupToPostgrest(c) : conditionToPostgrest(c))
        .filter(Boolean);

    if (group.link === '$or') return parts.join(',');
    return parts.length > 1 ? `and(${parts.join(',')})` : parts[0] || '';
}

export function applyDataFilter(query: any, filter: any): any {
    if (!filter?.conditions?.length) return query;

    if (filter.link === '$or') {
        const expr = groupToPostgrest(filter);
        if (expr) query = query.or(expr);
    } else {
        for (const condition of filter.conditions) {
            if (condition.link) {
                if (condition.link === '$or') {
                    const expr = groupToPostgrest(condition);
                    if (expr) query = query.or(expr);
                } else {
                    query = applyDataFilter(query, condition);
                }
            } else {
                const { operator, value } = condition;
                const column = Array.isArray(condition.field) ? condition.field.join('.') : condition.field;
                if (!column || !operator) continue;
                if (value === undefined || value === '') continue;
                if (condition.isEmptyIgnored && value === null) continue;

                query = query[operator](column, value);
            }
        }
    }

    return query;
}
