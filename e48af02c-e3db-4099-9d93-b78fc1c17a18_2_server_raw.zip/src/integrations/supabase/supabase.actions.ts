import { getSupabaseClient, buildSelectString, applyDataFilter, processSupabaseObjectData } from './supabase.utils.ts';
import { fileToDataURI, fileToBuffer, isDataURI, dataURIToBuffer, dataURIToContentType, findTableLinkData } from '../utils.ts';

global.registerAction('supabase/select', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const selectString = buildSelectString(args.columns, args.joinTypes);
    let query = client.from(args.table).select(selectString, args.count ? { count: args.count } : {});

    query = applyDataFilter(query, args.filters);

    for (const item of args.sort || []) {
        const column = Array.isArray(item.field) ? item.field.join('.') : item.field;
        if (column) query = query.order(column, { ascending: item.direction !== 'DESC' });
    }
    if (args.limit && args.offset) query = query.range(args.offset, args.offset + args.limit - 1);
    else if (args.limit) query = query.limit(args.limit);
    if (args.single) query = query.single() as any;
    else if (args.maybeSingle) query = query.maybeSingle() as any;

    const { data, error, count } = await query;
    if (error) throw error;
    return args.count ? { data, count } : data;
});

global.registerAction('supabase/insert', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const tableLinkData = findTableLinkData({
        integration: 'supabase',
        context,
        matchingFunction: (param: any) => param.tableConfig?.table === args.table,
    });
    const data = tableLinkData
        ? (args.data || []).map((item: Record<string, unknown>) => processSupabaseObjectData(item, tableLinkData))
        : args.data;

    const selectColumns = (args.returnColumns || []).join(',') || '*';
    const builder = client.from(args.table).insert(data);
    const { data: result, error } = await (args.returnMode === 'none' ? builder : builder.select(selectColumns));

    if (error) throw error;
    return result;
});

global.registerAction('supabase/update', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const tableLinkData = findTableLinkData({
        integration: 'supabase',
        context,
        matchingFunction: (param: any) => param.tableConfig?.table === args.table,
    });
    const updateData = tableLinkData ? processSupabaseObjectData(args.data || {}, tableLinkData) : args.data;

    const selectColumns = (args.returnColumns || []).join(',') || '*';
    let query = client.from(args.table).update(updateData);
    query = applyDataFilter(query, args.filters);
    const { data, error, count } = await (args.returnMode === 'none' ? query : query.select(selectColumns));

    if (error) throw error;
    return args.count ? { data, count } : data;
});

global.registerAction('supabase/upsert', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const tableLinkData = findTableLinkData({
        integration: 'supabase',
        context,
        matchingFunction: (param: any) => param.tableConfig?.table === args.table,
    });
    const data = tableLinkData
        ? (args.data || []).map((item: Record<string, unknown>) => processSupabaseObjectData(item, tableLinkData))
        : args.data;

    const selectColumns = (args.returnColumns || []).join(',') || '*';
    const builder = client.from(args.table).upsert(data, {
        onConflict: args.onConflict?.join(','),
        ignoreDuplicates: args.ignoreDuplicates,
    });
    const { data: result, error } = await (args.returnMode === 'none' ? builder : builder.select(selectColumns));

    if (error) throw error;
    return result;
});

global.registerAction('supabase/delete', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const selectColumns = (args.returnColumns || []).join(',') || '*';
    let query = client.from(args.table).delete();
    query = applyDataFilter(query, args.filters);
    const { data, error } = await (args.returnMode === 'none' ? query : query.select(selectColumns));

    if (error) throw error;
    return data;
});

global.registerAction('supabase/storage-list', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const { data, error } = await client.storage.from(args.id).list(args.path, {
        limit: args.limit,
        offset: args.offset,
        search: args.search,
        sortBy: args.sortBy,
    });

    if (error) throw error;
    return data;
});

global.registerAction('supabase/storage-upload', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    if (args.fileBody instanceof File) {
        if (!args.contentType && args.fileBody.type) {
            args.contentType = args.fileBody.type;
        }
        args.fileBody = await fileToBuffer(args.fileBody);
    } else if (isDataURI(args.fileBody)) {
        if (!args.contentType) {
            args.contentType = dataURIToContentType(args.fileBody);
        }
        args.fileBody = dataURIToBuffer(args.fileBody);
    }
    const { data, error } = await client.storage.from(args.id).upload(args.path, args.fileBody, {
        upsert: args.upsert,
        contentType: args.contentType,
        cacheControl: args.cacheControl,
    });

    if (error) throw error;
    return data;
});

global.registerAction('supabase/storage-remove', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const { data, error } = await client.storage.from(args.id).remove(args.paths);

    if (error) throw error;
    return data;
});

global.registerAction('supabase/storage-create-signed-url', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const { data, error } = await client.storage.from(args.id).createSignedUrl(args.path, args.expiresIn, {
        transform: args.transform,
    });

    if (error) throw error;
    return data;
});

global.registerAction('supabase/storage-get-public-url', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const { data } = client.storage.from(args.id).getPublicUrl(args.path, {
        download: args.download,
        transform: args.transform,
    });

    return data;
});

global.registerAction('supabase/storage-download', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const { data, error } = await client.storage.from(args.id).download(args.path);

    if (error) throw error;
    return await fileToDataURI(data);
});

global.registerAction('supabase/storage-update', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    if (args.fileBody instanceof File) {
        if (!args.contentType && args.fileBody.type) {
            args.contentType = args.fileBody.type;
        }
        args.fileBody = await fileToBuffer(args.fileBody);
    } else if (isDataURI(args.fileBody)) {
        if (!args.contentType) {
            args.contentType = dataURIToContentType(args.fileBody);
        }
        args.fileBody = dataURIToBuffer(args.fileBody);
    }
    const { data, error } = await client.storage.from(args.id).update(args.path, args.fileBody, {
        contentType: args.contentType,
        cacheControl: args.cacheControl,
    });

    if (error) throw error;
    return data;
});

global.registerAction('supabase/storage-move', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const { data, error } = await client.storage.from(args.id).move(args.fromPath, args.toPath);

    if (error) throw error;
    return data;
});

global.registerAction('supabase/storage-copy', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const { data, error } = await client.storage.from(args.id).copy(args.fromPath, args.toPath);

    if (error) throw error;
    return data;
});

global.registerAction('supabase/rpc', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    let query = client.rpc(args.fn, args.params);
    if (args.single) query = query.single() as any;
    const { data, error } = await query;

    if (error) throw error;
    return data;
});

global.registerAction('supabase/functions-invoke', async ({ args }: ActionParams, context: ActionContext) => {
    const client = getSupabaseClient(context.connection);

    const { data, error } = await client.functions.invoke(args.functionName, {
        method: args.method,
        body: args.body,
        headers: args.headers,
    });

    if (error) throw error;
    return data;
});
