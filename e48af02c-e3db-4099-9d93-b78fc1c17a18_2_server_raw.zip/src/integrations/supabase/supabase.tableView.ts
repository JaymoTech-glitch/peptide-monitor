import { getSupabaseClient, applyFilters, applyDataFilter, buildSelectString } from './supabase.utils.ts';

global.registerTableView('supabase', async (connection: ConnectionConfig, table: TableConfig, view: ViewConfig) => {
    const client = getSupabaseClient(connection);

    view.offset ||= 0;

    const selectString = buildSelectString(view.columns, view.joinTypes);
    let query = client.from(table.table).select(selectString, { count: view.count ?? 'exact' });

    if (view.filters?.link) {
        query = applyDataFilter(query, view.filters);
    } else if (view.filters?.length) {
        query = applyFilters(query, view.filters);
    }

    for (const item of view.sort || []) {
        const column = Array.isArray(item.field) ? item.field.join('.') : item.field;
        if (column) query = query.order(column, { ascending: item.direction !== 'DESC' });
    }

    if (view.limit) query = query.limit(view.limit);
    if (view.offset && view.limit) query = query.range(view.offset, view.offset + view.limit - 1);
    const { data, error, count } = await query;
    const nextOffset = view.offset + (data?.length || 0);

    if (error) throw error;
    return {
        data: data || [],
        metadata: {
            limit: view.limit || null,
            offset: view.offset,
            nextOffset: nextOffset >= count ? null : nextOffset,
            total: count || null,
        },
    };
});
