import { evaluateCodeAsync, createCodeContext, createWwFormulas } from '../../services/tmp/codeEval/utils.js';

type CustomJSActionParams = { code: string } & ActionParams;

global.registerAction('custom-js', async (action: CustomJSActionParams, context: ActionContext) => {
    const codeContext = createCodeContext(context);
    const wwFormulas = createWwFormulas(context);

    return await evaluateCodeAsync({ code: action.code, context: codeContext, wwFormulas });
});
