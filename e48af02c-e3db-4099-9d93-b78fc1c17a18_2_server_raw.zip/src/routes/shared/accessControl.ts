import { HTTPException } from 'hono/http-exception';
import workflowCore from '../../core/workflow.core.js';
import { getValue } from '../../services/tmp/utils/input.js';

type SecurityConfig = {
    accessRule?: string;
    accessRoles?: string[];
    accessRolesCondition?: string;
    accessMiddlewares?: Array<{ workflowId?: string; parameters?: unknown }>;
};

type AuthContext = {
    user?: { roles?: string[] };
    isAuthenticated?: boolean;
};

type AccessOptions = {
    skip?: boolean;
    detailedErrors?: boolean;
};

type ParameterDefinition = {
    key?: string;
    name?: string;
    value?: unknown;
    type: 'text' | 'number' | 'boolean' | 'number|string' | 'object';
};

function throwUnauthenticated(detailedErrors: boolean) {
    if (detailedErrors) {
        throw new HTTPException(401, { message: 'Unauthenticated access', cause: 'User is not authenticated' });
    }
    throw new HTTPException(401);
}

function throwUnauthorized(detailedErrors: boolean) {
    if (detailedErrors) {
        throw new HTTPException(403, { message: 'Unauthorized access', cause: 'Invalid roles' });
    }
    throw new HTTPException(403);
}

export function assertAccessRules(
    security: SecurityConfig | undefined,
    auth: AuthContext | undefined,
    options: AccessOptions = {}
) {
    if (security?.accessRule !== 'authenticated') return;
    if (!auth?.isAuthenticated) {
        throwUnauthenticated(!!options.detailedErrors);
    }

    if (!security?.accessRoles?.length) return;
    const condition = security.accessRolesCondition === 'AND' ? 'every' : 'some';
    const hasAccess = security.accessRoles[condition](role => auth?.user?.roles?.includes(role));
    if (hasAccess) return;
    throwUnauthorized(!!options.detailedErrors);
}

export async function executeAccessMiddlewares(
    security: SecurityConfig | undefined,
    workflows: Array<{ id?: string }> | undefined,
    context: Record<string, unknown>,
    socketId: string | null = null
) {
    const middlewares = security?.accessMiddlewares || [];
    for (const middleware of middlewares) {
        const workflow = workflows?.find(currentWorkflow => currentWorkflow.id === middleware.workflowId);
        if (!workflow) throw new HTTPException(403);

        const middlewareContext: Record<string, unknown> = {
            ...context,
            parameters: getValue(middleware.parameters, context),
        };

        if (socketId) {
            middlewareContext.socketId = socketId;
        }

        const result = await workflowCore.execute(workflow, middlewareContext);
        if (result instanceof Response) return result;
    }

    return null;
}

const DEFAULT_TABLE_VIEW_PARAMETERS: ParameterDefinition[] = [
    { name: 'offset', type: 'number|string' },
    { name: 'limit', type: 'number' },
];
export function parseTableViewQuery(definitions: ParameterDefinition[] = [], values: Record<string, string> = {}) {
    const result: Record<string, unknown> = {};
    for (const definition of [definitions, DEFAULT_TABLE_VIEW_PARAMETERS].flat()) {
        const parameterKey = definition?.key || definition?.name;
        if (!parameterKey) continue;

        if (Object.hasOwn(values, parameterKey)) {
            switch (definition.type) {
                case 'number|string':
                    if (values[parameterKey].match(/^\d+$/)) {
                        result[parameterKey] = parseFloat(values[parameterKey]);
                    } else {
                        result[parameterKey] = values[parameterKey];
                    }
                    break;
                case 'number':
                    result[parameterKey] = parseFloat(values[parameterKey]);
                    break;
                case 'boolean':
                    result[parameterKey] =
                        values[parameterKey] === 'true' ||
                        values[parameterKey] === 'TRUE' ||
                        values[parameterKey] === '1';
                    break;
                default:
                    result[parameterKey] = values[parameterKey];
            }
        } else {
            result[parameterKey] = definition.value;
        }
    }
    return result;
}
