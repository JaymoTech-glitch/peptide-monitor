import { Hono } from 'hono';
import { ensureWWAuth } from '../../middlewares/weweb.middlewares.js';
import {
    listAll,
    move,
    copy,
    deleteList,
    getSignedUrl,
    getSignedUploadUrl,
    confirmSignedUploadUrl,
    syncFile,
} from './storage.controllers.ts';

const ENV_PATH = ':env{(current|editor|staging|production)}';
const ACCESS_PATH = ':access{(public|private)}';

let app = new Hono();
app.patch('/files/signed-url/upload/confirm', confirmSignedUploadUrl);

if (process.env.ENV === 'editor') {
    app.patch(`/${ENV_PATH}/files/signed-url/upload/confirm`, ensureWWAuth, confirmSignedUploadUrl);
    app = app.basePath(`/${ENV_PATH}/${ACCESS_PATH}`);
    app.use('*', ensureWWAuth);
    app.get('/files', listAll);
    app.post('/files/delete', deleteList);
    app.patch('/files/move', move);
    app.post('/files/copy', copy);
    app.post('/files/signed-url', getSignedUrl);
    app.post('/files/signed-url/upload', getSignedUploadUrl);
    app.put('/files/sync', syncFile);
}

export default app;
