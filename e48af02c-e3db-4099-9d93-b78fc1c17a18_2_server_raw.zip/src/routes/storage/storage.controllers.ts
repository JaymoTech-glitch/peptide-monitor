import type { Context as HonoContext } from 'hono';
import { HTTPException } from 'hono/http-exception';
import storageCore, { type StorageAccess } from '../../core/storage.core.ts';
import { StorageError } from '../../core/storage.errors.ts';
import databaseService from '../../services/database/database.service.ts';

type StorageRouteOptions = Record<string, unknown>;

type StorageDbFile = {
    path: string;
    name: string;
    ext: string;
    type: string;
    size: number;
    updatedAt?: string | Date;
};

type MoveCopyBody = {
    source: string;
    destination: string;
    options?: StorageRouteOptions;
};

type SignedUrlBody = {
    path: string;
    options?: StorageRouteOptions;
};

type ConfirmSignedUploadUrlBody = {
    signedUploadUrl?: string;
};

type PendingSignedUploadFile = {
    access: StorageAccess;
    path: string;
};

function getStorageAccess(c: HonoContext) {
    const access = c.req.param('access');
    try {
        return storageCore.normalizeStorageAccess(access);
    } catch (_error) {
        throw new HTTPException(400, { message: 'Invalid storage access' });
    }
}

function getStorageEnv(c: HonoContext) {
    const env = c.req.param('env') || 'current';
    try {
        return storageCore.normalizeStorageEnv(env);
    } catch (_error) {
        throw new HTTPException(400, { message: 'Invalid storage environment' });
    }
}

function getDatabaseEnv(env: string) {
    if (env === 'current') return null;
    return env;
}

function toStorageHttpException(error: unknown) {
    if (error instanceof HTTPException) return error;
    if (error instanceof StorageError) {
        return new HTTPException(error.status, { message: error.message });
    }
    return new HTTPException(500, { message: String((error as Error)?.message || 'Internal Server Error') });
}

async function findPendingSignedUploadFile(signedUploadUrl: string, env: string): Promise<PendingSignedUploadFile | null> {
    const accesses = Object.keys(storageCore.ACCESS_TABLE_NAME) as StorageAccess[];

    for (const access of accesses) {
        const selectQuery = databaseService.getSelectQuery({
            schema: 'storage',
            table: storageCore.ACCESS_TABLE_NAME[access],
            columns: { path: true },
            filters: {
                link: '$and',
                conditions: [{ field: 'signedUploadUrl', operator: '$eq', value: signedUploadUrl }],
            },
            limit: 1,
        });
        const rows = (await databaseService.execute({
            ...selectQuery,
            env: getDatabaseEnv(env),
        })) as { path: string }[];

        if (!rows.length) continue;

        return { access, path: rows[0].path };
    }

    return null;
}

export const confirmSignedUploadUrl = async (c: HonoContext) => {
    const env = getStorageEnv(c);
    const { signedUploadUrl } = (await c.req.json()) as ConfirmSignedUploadUrlBody;
    if (!signedUploadUrl) throw new HTTPException(400, { message: 'Invalid signed upload URL' });

    const pendingFile = await findPendingSignedUploadFile(signedUploadUrl, env);
    if (!pendingFile) throw new HTTPException(404, { message: 'Signed upload URL not found' });

    const { access, path } = pendingFile;

    const disk = storageCore.getDisk(access, env);

    if (!(await disk.exists(path))) throw new HTTPException(404);
    const fileMetadata = await disk.getMetaData(path);

    const normalizedPath = storageCore.normalizePath(path, { catchError: true });
    const updateQuery = databaseService.getUpdateQuery({
        schema: 'storage',
        table: storageCore.ACCESS_TABLE_NAME[access],
        data: {
            signedUploadUrl: null,
            signedUploadUrlExpiresAt: null,
            type: fileMetadata.contentType || 'application/octet-stream',
            size: fileMetadata.contentLength,
        },
        filters: {
            link: '$and',
            conditions: [
                { field: 'path', operator: '$eq', value: normalizedPath },
                { field: 'signedUploadUrl', operator: '$eq', value: signedUploadUrl },
            ],
        },
        returnData: true,
    });
    const newFile = await databaseService.execute({
        ...updateQuery,
        env: getDatabaseEnv(env),
    });

    return c.json(newFile[0], 200);
};

export const listAll = async (c: HonoContext) => {
    const access = getStorageAccess(c);
    const env = getStorageEnv(c);
    const prefix = c.req.query('prefix') || '';
    const paginationToken = c.req.query('paginationToken') || c.req.query('offset') || null;
    const recursive = c.req.query('recursive');
    const maxResults = c.req.query('maxResults');
    const options: StorageRouteOptions = {};

    if (paginationToken) options.paginationToken = paginationToken;
    if (recursive !== undefined) options.recursive = recursive !== 'false';
    if (maxResults !== undefined) {
        const parsedMaxResults = Number(maxResults);
        if (Number.isFinite(parsedMaxResults) && parsedMaxResults > 0) {
            options.maxResults = parsedMaxResults;
        }
    }

    const disk = storageCore.getDisk(access, env);

    const result = await disk.listAll(prefix, options);
    const objects = Array.from(result.objects);

    const normalizedPrefix = storageCore.normalizePath(prefix, { catchError: true });
    const selectQuery = databaseService.getSelectQuery({
        schema: 'storage',
        table: storageCore.ACCESS_TABLE_NAME[access],
        columns: { path: true, name: true, prefix: true, ext: true, type: true, size: true, updatedAt: true },
        filters: {
            link: '$and',
            conditions: [
                { field: 'path', operator: '$iLike:startsWith', value: normalizedPrefix },
                { field: 'signedUploadUrl', operator: '$eq:null' },
            ],
        },
    });
    const dbFiles = (await databaseService.execute({
        ...selectQuery,
        env: getDatabaseEnv(env),
    })) as StorageDbFile[];

    const items = [];
    for (const object of objects) {
        if (object.isDirectory) {
            items.push({
                isDirectory: object.isDirectory,
                name: object.name,
            });
            continue;
        }

        if (!object.isFile) continue;

        const normalizedPath = storageCore.normalizePath(object.key);
        const existingFile = dbFiles.find(file => file.path === normalizedPath);
        if (existingFile) {
            items.push({
                isFile: object.isFile,
                path: existingFile.path,
                name: existingFile.name,
                ext: existingFile.ext,
                type: existingFile.type,
                size: existingFile.size,
                updatedAt: existingFile.updatedAt,
                isSynced: true,
            });
            continue;
        }

        const metadata = await disk.getMetaData(object.key);
        items.push({
            isFile: object.isFile,
            ...storageCore.getFileBaseData(normalizedPath),
            type: metadata.contentType,
            size: metadata.contentLength,
            updatedAt: metadata.lastModified,
            isSynced: false,
        });
    }

    return c.json(
        {
            prefix: normalizedPrefix,
            items,
            nextToken: result.paginationToken,
            offset: result.paginationToken,
        },
        200
    );
};

export const move = async (c: HonoContext) => {
    const access = getStorageAccess(c);
    const env = getStorageEnv(c);
    const { source, destination, options = {} } = (await c.req.json()) as MoveCopyBody;
    try {
        const result = await storageCore.move(access, source, destination, options, env);
        return c.json(result, 200);
    } catch (error) {
        throw toStorageHttpException(error);
    }
};

export const copy = async (c: HonoContext) => {
    const access = getStorageAccess(c);
    const env = getStorageEnv(c);
    const { source, destination, options = {} } = (await c.req.json()) as MoveCopyBody;
    try {
        const result = await storageCore.copy(access, source, destination, options, env);
        return c.json(result, 200);
    } catch (error) {
        throw toStorageHttpException(error);
    }
};

export const deleteList = async (c: HonoContext) => {
    const access = getStorageAccess(c);
    const env = getStorageEnv(c);
    const { paths } = await c.req.json();

    const deleted = [];
    const failed = [];

    await Promise.all(
        paths.map(async (path: string) => {
            try {
                await storageCore.delete(access, path, env);
                deleted.push(path);
            } catch (e) {
                failed.push(path);
            }
        })
    );

    return c.json({ deleted, failed }, 200);
};

export const getSignedUrl = async (c: HonoContext) => {
    const access = getStorageAccess(c);
    const env = getStorageEnv(c);
    const { path, options = {} } = (await c.req.json()) as SignedUrlBody;

    const result = await storageCore.getSignedUrl(access, path, options, env);

    return c.json(result, 200);
};

export const getSignedUploadUrl = async (c: HonoContext) => {
    const access = getStorageAccess(c);
    const env = getStorageEnv(c);
    const { path, options = {} } = (await c.req.json()) as SignedUrlBody;

    const result = await storageCore.getSignedUploadUrl(access, path, options, env);

    return c.json(result, 200);
};

export const syncFile = async (c: HonoContext) => {
    const access = getStorageAccess(c);
    const env = getStorageEnv(c);
    const { path } = await c.req.json();

    const disk = storageCore.getDisk(access, env);

    if (!(await disk.exists(path))) throw new HTTPException(404);
    const metadata = await disk.getMetaData(path);

    const normalizedPath = storageCore.normalizePath(path);
    const updateQuery = databaseService.getInsertQuery({
        schema: 'storage',
        table: storageCore.ACCESS_TABLE_NAME[access],
        data: {
            ...storageCore.getFileBaseData(normalizedPath),
            type: metadata.contentType,
            size: metadata.contentLength,
            signedUploadUrl: null,
            signedUploadUrlExpiresAt: null,
        },
        primaryColumn: 'path',
        upsert: true,
    });
    await databaseService.execute({
        ...updateQuery,
        env: getDatabaseEnv(env),
    });

    return c.json({}, 200);
};
