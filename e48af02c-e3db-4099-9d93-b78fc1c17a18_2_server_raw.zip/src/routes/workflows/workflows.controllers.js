import { HTTPException } from 'hono/http-exception';
import { resolveConnections } from '../../services/connection.service.js';
import workflowCore from '../../core/workflow.core.js';
import wewebService from '../../services/weweb.service.js';
import { getCookie } from 'hono/cookie';
import { inflateSync } from 'node:zlib';
import { assertAccessRules, executeAccessMiddlewares } from '../shared/accessControl.ts';
import WORKFLOWS from '../../data/workflows.json' with { type: 'json' };
import CONNECTIONS from '../../data/connections.json' with { type: 'json' };

function decodePreviousResults(encodedPreviousResults) {
    if (!encodedPreviousResults) return null;

    try {
        const compressedValue = Buffer.from(encodedPreviousResults, 'base64');
        const serializedValue = inflateSync(compressedValue).toString('utf-8');
        const parsedValue = JSON.parse(serializedValue);
        if (!parsedValue || typeof parsedValue !== 'object') return null;
        return parsedValue;
    } catch (error) {
        return null;
    }
}

export const executeEditorWorkflow = async c => {
    const basePath = process.env.LAMBDA_INVOKE_MODE === 'STREAM' ? '/api/stream' : '/api';
    const method = c.req.method;
    const rawPath = c.req.path;
    const path = rawPath.startsWith(basePath) ? rawPath.slice(basePath.length) : rawPath;
    const socketId = c.req.header('ww-socket-id');
    const debug = c.req.header('ww-debug') === 'true';
    const isTest = c.req.header('ww-editor-test') === 'true';
    const testActionId = c.req.header('ww-editor-action-id');
    const previousResults = decodePreviousResults(c.req.header('ww-editor-previous-results'));

    const editorUserId = c.req.header('ww-editor-user-id');
    const options = { socketId, editorUserId };
    const matchResult = await wewebService.matchWorkflowByPath(method, path, options);

    if (!matchResult) {
        throw new HTTPException(404);
    }

    const { workflow, subWorkflows, pathParams } = matchResult;
    if (!workflow) {
        throw new HTTPException(404);
    }

    c.set('workflow', workflow);

    if (testActionId && workflow.actions?.[testActionId]) {
        workflow.firstAction = testActionId;
        workflow.actions[testActionId].next = null;
        workflow.actions[testActionId].branches = [];
    }

    const workflowContext = await prepareEditorContext(
        c,
        Object.values(subWorkflows || {}),
        pathParams,
        previousResults
    );

    try {
        if (!isTest) {
            assertAccessRules(workflow.meta?.security, workflowContext.auth, { detailedErrors: true });
            const middlewareResponse = await executeAccessMiddlewares(
                workflow.meta?.security,
                workflowContext.workflows,
                workflowContext,
                socketId
            );
            if (middlewareResponse) {
                return middlewareResponse;
            }
        }

        const result = await new Promise(async (resolve, reject) => {
            if (!debug) workflowContext.sendResponse = resolve;
            workflowContext.throwError = reject;
            resolve(await workflowCore.execute(workflow, workflowContext, socketId));
        });

        if (debug) return c.json({ debug: wewebService.sanitizeWorkflowDebugResults(workflowContext.workflow) });
        else if (result instanceof Response) return result;
        else if (c.res) return c.res;
        else return c.json(result);
    } catch (err) {
        if (debug)
            return c.json(
                { debug: { results: wewebService.sanitizeWorkflowDebugResults(workflowContext.workflow) } },
                { status: 500 }
            );
        throw err instanceof Error ? err : Object.assign(new Error(err?.message || 'Internal Server Error'), err);
    }
};

export const executeWorkflow = async c => {
    const workflow = c.get('workflow');
    const workflowContext = await prepareContext(c);

    assertAccessRules(workflow.meta?.security, workflowContext.auth, { detailedErrors: true });

    try {
        const middlewareResponse = await executeAccessMiddlewares(
            workflow.meta?.security,
            workflowContext.workflows,
            workflowContext
        );
        if (middlewareResponse) {
            return middlewareResponse;
        }

        const result = await new Promise(async (resolve, reject) => {
            workflowContext.sendResponse = resolve;
            workflowContext.throwError = reject;
            resolve(await workflowCore.execute(workflow, workflowContext));
        });

        if (result instanceof Response) return result;
        else if (c.res) return c.res;
        else return c.json(result);
    } catch (err) {
        throw err instanceof Error ? err : Object.assign(new Error(err?.message || 'Internal Server Error'), err);
    }
};

async function prepareContext(c) {
    const method = c.req.method;
    const isGetOrDelete = ['GET', 'DELETE'].includes(method.toUpperCase());
    const query = c.req.query();
    const body = await parseRequestBody(c, isGetOrDelete);
    const headers = c.req.raw.headers;
    const cookies = getCookie(c);
    const path = c.req.path;

    return {
        http: { method, query, body, headers, cookies, path },
        auth: {
            user: c.get('user'),
            session: c.get('session'),
            isAuthenticated: !!c.get('user'),
        },
        workflows: WORKFLOWS,
        connections: resolveConnections(CONNECTIONS),
        parameters: isGetOrDelete ? query : body,
        previousResults: null,
        honoContext: c,
        response: null,
    };
}

async function prepareEditorContext(c, subWorkflows, pathParams = {}, previousResults = null) {
    const method = c.req.method;
    const isGetOrDelete = ['GET', 'DELETE'].includes(method.toUpperCase());
    const query = c.req.query();
    const headers = c.req.raw.headers;
    const cookies = getCookie(c);
    const path = c.req.path;
    const body = await parseRequestBody(c, isGetOrDelete);

    const parameters = { ...pathParams, ...(isGetOrDelete ? query : body) };

    return {
        http: { method, query, body, headers, cookies, path, pathParams },
        auth: {
            user: c.get('user'),
            session: c.get('session'),
            isAuthenticated: !!c.get('user'),
        },
        workflows: subWorkflows,
        connections: resolveConnections(CONNECTIONS),
        parameters,
        previousResults,
        honoContext: c,
        response: null,
    };
}

async function parseRequestBody(c, isGetOrDelete) {
    if (isGetOrDelete) return null;
    const contentType = c.req.header('content-type') || '';
    if (!contentType.includes('multipart/form-data') && !contentType.includes('application/x-www-form-urlencoded')) {
        return await c.req.json().catch(() => ({}));
    }

    const formData = await c.req.formData().catch(() => null);
    if (!formData) return {};

    return parseFormDataBody(formData);
}

function parseFormDataBody(formData) {
    const formDataEntries = Object.fromEntries(formData.entries());
    const body = {};
    const filesSet = [];

    for (const key in formDataEntries) {
        if (!Object.hasOwn(formDataEntries, key)) continue;
        if (key.startsWith('fileParam[')) {
            const keyParam = key.replace(/fileParam\[[^\]]*\]-/, '');
            const file = formData.get(key);
            if (!filesSet.includes(keyParam)) {
                filesSet.push(keyParam);
                body[keyParam] = [];
            }
            body[keyParam].push(file);
            continue;
        }

        if (key.startsWith('fileParam-')) {
            const keyParam = key.replace(/fileParam-/, '');
            const file = formData.get(key);
            if (!filesSet.includes(keyParam)) {
                filesSet.push(keyParam);
            }
            body[keyParam] = file;
            continue;
        }

        body[key] = parseFormField(formDataEntries[key]);
    }

    return body;
}

function parseFormField(value) {
    if (typeof value !== 'string') return value;
    try {
        return JSON.parse(value);
    } catch {
        return value;
    }
}
