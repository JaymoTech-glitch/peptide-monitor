import { HTTPException } from 'hono/http-exception';
import databaseService from '../../services/database/database.service.ts';
import { getValue } from '../../services/tmp/utils/input.js';
import { throwDbError } from '../../utils/dbError.js';
import { convertConfig } from '../../utils/configConverter.ts';

export const queryTableSelect = async c => {
    try {
        const env = c.req.param('env');
        const {
            tableName,
            schema,
            columns,
            filters,
            sort,
            limit = 50,
            offset = 0,
            includes = [],
            parameters = {},
        } = await c.req.json();
        if (!tableName) return new HTTPException(400);

        const context = { parameters: parameters || {} };
        const resolvedConfig = {
            table: tableName,
            schema,
            columns,
            filters: getValue(filters, context),
            sort: getValue(sort, context),
            includes,
            limit,
            offset,
        };
        const convertedConfig = convertConfig(resolvedConfig);

        const selectQuery = databaseService.getSelectQuery({
            table: convertedConfig.table,
            schema: convertedConfig.schema,
            columns: convertedConfig.columns,
            filters: convertedConfig.filters,
            sort: convertedConfig.sort,
            limit: convertedConfig.limit,
            offset: convertedConfig.offset,
            includes: convertedConfig.includes,
        });
        const countQuery = databaseService.getCountQuery({
            table: convertedConfig.table,
            schema: convertedConfig.schema,
            filters: convertedConfig.filters,
            includes: convertedConfig.includes,
        });

        const [result, countResult] = await Promise.all([
            databaseService.execute({
                ...selectQuery,
                env,
            }),
            databaseService.execute({
                ...countQuery,
                env,
            }),
        ]);

        return c.json({
            data: result,
            metadata: {
                limit: limit,
                offset: offset || 0,
                total: parseInt(countResult[0].count),
            },
        });
    } catch (err) {
        throwDbError(err);
    }
};

export const queryTableInsert = async c => {
    try {
        const env = c.req.param('env');
        const { tableName, data, upsert = false, returnData = false } = await c.req.json();
        if (!tableName || !data) return new HTTPException(400);

        const insertQuery = databaseService.getInsertQuery({
            table: tableName,
            data,
            upsert,
            returnData,
        });

        const result = await databaseService.execute({
            query: insertQuery.query,
            params: insertQuery.params,
            env,
        });

        return c.json(result);
    } catch (err) {
        throwDbError(err);
    }
};

export const queryTableUpdate = async c => {
    try {
        const env = c.req.param('env');
        const { tableName, data, filters, returnData = false } = await c.req.json();
        if (!tableName || !data || !filters) return new HTTPException(400);

        const updateQuery = databaseService.getUpdateQuery({
            table: tableName,
            data,
            filters,
            returnData,
        });

        const result = await databaseService.execute({
            query: updateQuery.query,
            params: updateQuery.params,
            env,
        });

        return c.json(result);
    } catch (err) {
        throwDbError(err);
    }
};

export const queryTableDelete = async c => {
    try {
        const env = c.req.param('env');
        const { tableName, filters, returnData = false } = await c.req.json();
        if (!tableName || !filters) return new HTTPException(400);

        const deleteQuery = databaseService.getDeleteQuery({
            table: tableName,
            filters,
            returnData,
        });
        const result = await databaseService.execute({
            query: deleteQuery.query,
            params: deleteQuery.params,
            env,
        });

        return c.json(result);
    } catch (err) {
        throwDbError(err);
    }
};

export const getTables = async c => {
    try {
        const env = c.req.param('env');

        const dbPool = databaseService.getPool(env);
        if (!dbPool) return new HTTPException(400);

        // TODO

        return c.json({});
    } catch (err) {
        throwDbError(err);
    }
};

export const alterTables = async c => {
    try {
        const { tableName } = await c.req.json();
        if (!tableName) return new HTTPException(400);

        const dbPool = databaseService.getPool('editor');
        if (!dbPool) return new HTTPException(400);

        // TODO

        return c.json({});
    } catch (err) {
        throwDbError(err);
    }
};
