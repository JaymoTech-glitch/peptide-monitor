import { HTTPException } from 'hono/http-exception';
import databaseService from '../../services/database/database.service.ts';
import { getValue } from '../../services/tmp/utils/input.js';
import { throwDbError } from '../../utils/dbError.js';
import { resolveConnectionConfig } from '../../services/connection.service.js';
import wewebService from '../../services/weweb.service.js';
import { SecurityCheckError } from '../../core/errors.core.js';
import { convertConfig } from '../../utils/configConverter.ts';
import { applyFormulaColumns, prepareFormulaColumns } from '../../services/database/formulaColumns.ts';
import { parseTableViewQuery, assertAccessRules, executeAccessMiddlewares } from '../shared/accessControl.ts';
import TABLE_VIEWS from '../../data/tableViews.json' with { type: 'json' };
import CONNECTIONS from '../../data/connections.json' with { type: 'json' };
import INTEGRATION_TABLES from '../../data/integrationTables.json' with { type: 'json' };
import WORKFLOWS from '../../data/workflows.json' with { type: 'json' };

export const fetchWWTableView = async c => {
    try {
        const tableViewId = c.req.param('tableViewId');
        if (!tableViewId) throw new HTTPException(400);

        const isTest = c.req.header('ww-editor-test') === 'true';
        const editorEnv = c.req.header('ww-editor-env') || undefined;
        const options = {
            socketId: c.req.header('ww-socket-id'),
            editorUserId: c.req.header('ww-editor-user-id'),
            wwEditionMode: c.req.query('wwEditionMode') || undefined,
        };
        const result = await wewebService.getTableViewById(tableViewId, options);
        if (!result) throw new HTTPException(404);

        const { tableView, integrationTable, workflows } = result;
        const query = c.req.query();
        c.set('tableView', tableView); // For logging purposes

        const queryParams = parseTableViewQuery(tableView.parameters || [], query);

        const context = {
            env: editorEnv,
            parameters: queryParams,
            auth: {
                user: c.get('user'),
                session: c.get('session'),
                isAuthenticated: !!c.get('user'),
            },
            honoContext: c,
        };

        if (!isTest) {
            const security = tableView.security;
            assertAccessRules(security, context.auth, { detailedErrors: true });
            const middlewareResponse = await executeAccessMiddlewares(security, workflows, context);
            if (middlewareResponse) {
                return c.res;
            }
        }

        const { data, metadata } = await _fetchTableView({
            context,
            config: tableView.config,
            integrationTable,
            connection: integrationTable ? CONNECTIONS[integrationTable.connectionId] : null,
            env: editorEnv,
        });
        return c.json({ data, metadata });
    } catch (err) {
        if (err instanceof HTTPException || err instanceof SecurityCheckError) {
            throw err;
        }
        throwDbError(err);
    }
};

export const fetchTableView = async c => {
    try {
        const tableViewId = c.req.param('tableViewId');
        if (!tableViewId) throw new HTTPException(400);

        const tableView = TABLE_VIEWS[tableViewId];
        if (!tableView) throw new HTTPException(404);
        c.set('tableView', tableView); // For logging purposes

        const queryParams = parseTableViewQuery(tableView.parameters || [], c.req.query());

        const context = {
            parameters: queryParams,
            auth: {
                user: c.get('user'),
                session: c.get('session'),
                isAuthenticated: !!c.get('user'),
            },
            honoContext: c,
        };

        assertAccessRules(tableView.security, context.auth);
        const middlewareResponse = await executeAccessMiddlewares(tableView.security, WORKFLOWS, context);
        if (middlewareResponse) {
            return c.res;
        }

        const integrationTable = INTEGRATION_TABLES[tableView.tableId];
        if (tableView.tableId && !integrationTable) throw new HTTPException(404);
        const connectionId = integrationTable?.connectionId;
        const connection = CONNECTIONS[connectionId];
        if (connectionId && !connection) throw new HTTPException(404);

        const { data, metadata } = await _fetchTableView({
            context,
            config: tableView.config,
            integrationTable,
            connection,
        });
        return c.json({ data, metadata });
    } catch (err) {
        if (err instanceof HTTPException) {
            throw err;
        }
        throwDbError(err);
    }
};

async function _fetchTableView({ context, config, integrationTable, connection, env }) {
    const localConfig = { ...config }; // Avoid mutating original config
    localConfig.limit = context.parameters.limit ?? localConfig.limit;
    localConfig.offset = context.parameters.offset ?? localConfig.offset;
    if (integrationTable) {
        const resolvedConnection = resolveConnectionConfig(connection?.config, { env });
        const result = await global.tableViews[integrationTable.integration](
            resolvedConnection,
            getValue(integrationTable.config, context),
            getValue(localConfig, context)
        );
        return result;
    } else {
        if (!localConfig.table) throw new HTTPException(400, { message: 'Table name is required' });
        localConfig.offset ||= 0;

        const resolvedConfig = {
            ...localConfig,
            filters: getValue(localConfig.filters, context),
            sort: getValue(localConfig.sort, context),
            includes:
                localConfig.includes?.map(inc => ({
                    ...inc,
                    filters: getValue(inc.filters, context),
                    sort: getValue(inc.sort, context),
                })) || [],
        };
        const convertedConfig = convertConfig(resolvedConfig);
        const schema = convertedConfig.schema || 'public';
        const { hasFormulaColumns, materializedColumns, normalizedColumns } = prepareFormulaColumns(
            convertedConfig.columns,
            resolvedConfig.formulaColumns,
            {
                schema,
                table: convertedConfig.table,
                includes: convertedConfig.includes,
            }
        );

        const selectQuery = databaseService.getSelectQuery({
            schema,
            table: convertedConfig.table,
            columns: materializedColumns,
            filters: convertedConfig.filters,
            sort: convertedConfig.sort,
            limit: localConfig.limit,
            offset: localConfig.offset,
            includes: convertedConfig.includes,
            format: 'pretty',
        });
        const countQuery = databaseService.getCountQuery({
            schema,
            table: convertedConfig.table,
            filters: convertedConfig.filters,
            includes: convertedConfig.includes,
        });

        const [result, countResult] = await Promise.all([
            databaseService.execute({ ...selectQuery, env }),
            databaseService.execute({ ...countQuery, env }),
        ]);
        const data = hasFormulaColumns ? applyFormulaColumns(result, normalizedColumns, context) : result;
        const nextOffset = localConfig.offset + result.length;

        return {
            data,
            metadata: {
                limit: localConfig.limit,
                offset: localConfig.offset,
                nextOffset: nextOffset >= countResult[0].count ? null : nextOffset,
                total: parseInt(countResult[0].count),
            },
        };
    }
}
