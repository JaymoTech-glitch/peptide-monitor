import { Disk, KeyNormalizer } from 'flydrive';
import type { DriverContract, SignedURLOptions, WriteOptions } from 'flydrive/types';
import CONNECTIONS from '../data/connections.json' with { type: 'json' };
import {
    StorageConflictError,
    StorageNotFoundError,
    StorageUnsupportedOperationError,
} from './storage.errors.ts';
import { resolveConnectionConfig } from '../services/connection.service.js';
import { getEnv, type RuntimeEnv } from '../services/env.service.ts';
import { getStorageDriver } from '../services/storageDriverRegistry.service.ts';
import databaseService from '../services/database/database.service.ts';

const keyNormalizer = new KeyNormalizer();

export type StorageAccess = 'public' | 'private';
export type StorageEnv = RuntimeEnv;

export const normalizePath = (path: string, options: { catchError?: boolean } = {}): string => {
    try {
        return keyNormalizer.normalize(path);
    } catch (error) {
        if (options.catchError) return '';
        throw error;
    }
};

export function normalizeStorageAccess(access: string): StorageAccess {
    if (access === 'public' || access === 'private') return access;
    throw new Error('Invalid storage access');
}

export function normalizeStorageEnv(env: string = 'current'): StorageEnv {
    if (env === 'current' || env === 'editor' || env === 'staging' || env === 'production') return env;
    throw new Error('Invalid storage environment');
}

export const ACCESS_TABLE_NAME: Record<StorageAccess, string> = {
    public: 'publicFiles',
    private: 'privateFiles',
};

type StorageOptions = {
    overwrite?: boolean;
    expiresIn?: number | string;
} & Record<string, unknown>;

type StorageWriteOptions = WriteOptions & StorageOptions;
type StorageSignedUrlOptions = SignedURLOptions & StorageOptions;
type StorageCopyMoveOptions = WriteOptions & StorageOptions;
type StorageData = Parameters<DriverContract['put']>[1];

type StorageRuntimeConfig = {
    env: StorageEnv;
    integration?: string;
    connectionId?: string;
    cdnUrl?: string;
    privateBucket?: string;
    publicBucket?: string;
    privatePrefix?: string;
    publicPrefix?: string;
    appUrl?: string;
    proxyUrl?: string;
    projectId?: string;
};

function getDatabaseEnv(env: StorageEnv) {
    if (env === 'current') return null;
    return env;
}

export function resolveStorageRuntimeConfig(env: StorageEnv = 'current'): StorageRuntimeConfig {
    const normalizedEnv = normalizeStorageEnv(env);

    return {
        env: normalizedEnv,
        integration: getEnv('STORAGE_INTEGRATION', normalizedEnv),
        connectionId: getEnv('STORAGE_CONNECTION_ID', normalizedEnv),
        cdnUrl: getEnv('STORAGE_CDN_URL', normalizedEnv),
        privateBucket: getEnv('STORAGE_PRIVATE_BUCKET', normalizedEnv),
        publicBucket: getEnv('STORAGE_PUBLIC_BUCKET', normalizedEnv),
        privatePrefix: getEnv('STORAGE_PRIVATE_PREFIX', normalizedEnv) ?? 'private/',
        publicPrefix: getEnv('STORAGE_PUBLIC_PREFIX', normalizedEnv) ?? 'public/',
        appUrl: getEnv('APP_URL', normalizedEnv),
        proxyUrl: getEnv('S3_LAMBDA_URL', normalizedEnv),
        projectId: getEnv('WEWEB_PROJECT_ID', normalizedEnv),
    };
}

export function getFileBaseData(path: string) {
    const normalizedPath = normalizePath(path);
    const name = normalizedPath.split('/').pop();

    return {
        path: normalizedPath,
        name,
        prefix: normalizedPath.split('/').slice(0, -1).join('/'),
        ext: name?.split('.').pop() || '',
    };
}

function normalizeContentType(contentType: unknown): string {
    if (typeof contentType !== 'string') return 'application/octet-stream';
    const normalizedContentType = contentType.trim();
    return normalizedContentType || 'application/octet-stream';
}

async function findFile(access: StorageAccess, path: string, env: StorageEnv = 'current') {
    const normalizedPath = normalizePath(path);

    const selectQuery = databaseService.getSelectQuery({
        schema: 'storage',
        table: ACCESS_TABLE_NAME[access],
        columns: { path: true },
        filters: {
            link: '$and',
            conditions: [
                { field: 'path', operator: '$eq', value: normalizedPath },
                { field: 'signedUploadUrl', operator: '$eq:null' },
            ],
        },
    });
    const result = await databaseService.execute({
        ...selectQuery,
        env: getDatabaseEnv(env),
    });
    return result[0] || null;
}

async function assertFileExists(access: StorageAccess, path: string, env: StorageEnv = 'current') {
    const file = await findFile(access, path, env);
    if (!file) throw new StorageNotFoundError();
    return file;
}

async function assertFileDoesNotExist(access: StorageAccess, path: string, env: StorageEnv = 'current') {
    const file = await findFile(access, path, env);
    if (file) throw new StorageConflictError();
}

function isUnsupportedOperationError(error: unknown) {
    const message = String((error as Error)?.message || '').toLowerCase();
    return message.includes('unsupported operation');
}

async function updateMovedFileInDatabase(
    access: StorageAccess,
    source: string,
    destination: string,
    overwrite: boolean,
    env: StorageEnv
) {
    const normalizedSource = normalizePath(source);
    const normalizedDestination = normalizePath(destination);
    const fileBaseData = getFileBaseData(destination);

    if (overwrite) {
        const pool = databaseService.getPool(getDatabaseEnv(env));
        if (!pool) {
            throw new Error(`No database pool available for environment: ${env}`);
        }

        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            await client.query(
                `
                    DELETE FROM storage."${ACCESS_TABLE_NAME[access]}"
                    WHERE path = $1 AND path <> $2
                `,
                [normalizedDestination, normalizedSource]
            );
            const result = await client.query(
                `
                    UPDATE storage."${ACCESS_TABLE_NAME[access]}"
                    SET path = $1, name = $3, prefix = $4, ext = $5
                    WHERE path = $2
                    RETURNING *
                `,
                [normalizedDestination, normalizedSource, fileBaseData.name, fileBaseData.prefix, fileBaseData.ext]
            );
            await client.query('COMMIT');
            return result.rows[0];
        } catch (error) {
            await client.query('ROLLBACK').catch(() => {});
            throw error;
        } finally {
            client.release();
        }
    }

    const updateQuery = databaseService.getUpdateQuery({
        schema: 'storage',
        table: ACCESS_TABLE_NAME[access],
        filters: {
            link: '$and',
            conditions: [{ field: 'path', operator: '$eq', value: normalizedSource }],
        },
        data: {
            ...fileBaseData,
            path: normalizedDestination,
        },
        returnData: true,
    });
    const result = await databaseService.execute({
        ...updateQuery,
        env: getDatabaseEnv(env),
    });

    return result[0];
}

export const get = async (access: StorageAccess, path: string, env: StorageEnv = 'current') => {
    const normalizedAccess = normalizeStorageAccess(access);
    const normalizedEnv = normalizeStorageEnv(env);
    const disk = getDisk(normalizedAccess, normalizedEnv);

    await assertFileExists(normalizedAccess, path, normalizedEnv);

    return await disk.get(path);
};

export const getBytes = async (access: StorageAccess, path: string, env: StorageEnv = 'current') => {
    const normalizedAccess = normalizeStorageAccess(access);
    const normalizedEnv = normalizeStorageEnv(env);
    const disk = getDisk(normalizedAccess, normalizedEnv);

    await assertFileExists(normalizedAccess, path, normalizedEnv);

    return await disk.getBytes(path);
};

export const put = async (
    access: StorageAccess,
    path: string,
    data: StorageData,
    options: StorageWriteOptions = {},
    env: StorageEnv = 'current'
) => {
    const normalizedAccess = normalizeStorageAccess(access);
    const normalizedEnv = normalizeStorageEnv(env);
    const disk = getDisk(normalizedAccess, normalizedEnv);

    if (!options.overwrite) {
        await assertFileDoesNotExist(normalizedAccess, path, normalizedEnv);
    }

    await disk.put(path, data, options);

    const metadata = await disk.getMetaData(path);
    const upsertQuery = databaseService.getInsertQuery({
        schema: 'storage',
        table: ACCESS_TABLE_NAME[normalizedAccess],
        data: {
            ...getFileBaseData(path),
            size: metadata.contentLength,
            type: metadata.contentType,
        },
        upsert: true,
        primaryColumn: 'path',
        returnData: true,
    });
    const result = await databaseService.execute({
        ...upsertQuery,
        env: getDatabaseEnv(normalizedEnv),
    });

    return result[0];
};

export const getSignedUrl = async (
    access: StorageAccess,
    path: string,
    options: StorageSignedUrlOptions = {},
    env: StorageEnv = 'current'
) => {
    const normalizedAccess = normalizeStorageAccess(access);
    const normalizedEnv = normalizeStorageEnv(env);
    const disk = getDisk(normalizedAccess, normalizedEnv);

    await assertFileExists(normalizedAccess, path, normalizedEnv);

    return await disk.getSignedUrl(path, options as StorageSignedUrlOptions);
};

export const getSignedUploadUrl = async (
    access: StorageAccess,
    path: string,
    options: StorageSignedUrlOptions = {},
    env: StorageEnv = 'current'
) => {
    const normalizedAccess = normalizeStorageAccess(access);
    const normalizedEnv = normalizeStorageEnv(env);
    const disk = getDisk(normalizedAccess, normalizedEnv);

    if (!options.overwrite) {
        await assertFileDoesNotExist(normalizedAccess, path, normalizedEnv);
    }

    const uploadSignedUrl = await disk.getSignedUploadUrl(path, options);

    const deleteQuery = databaseService.getDeleteQuery({
        schema: 'storage',
        table: ACCESS_TABLE_NAME[normalizedAccess],
        filters: {
            link: '$and',
            conditions: [
                { field: 'signedUploadUrl', operator: '$ne:null' },
                { field: 'signedUploadUrlExpiresAt', operator: '$lt', value: new Date(Date.now()) },
            ],
        },
    });
    await databaseService.execute({
        ...deleteQuery,
        env: getDatabaseEnv(normalizedEnv),
    });

    const insertFile = databaseService.getInsertQuery({
        schema: 'storage',
        table: ACCESS_TABLE_NAME[normalizedAccess],
        data: {
            ...getFileBaseData(path),
            type: normalizeContentType(options.contentType),
            size: 0,
            signedUploadUrl: uploadSignedUrl,
            signedUploadUrlExpiresAt: new Date(Date.now() + (Number(options.expiresIn) || 60 * 30) * 1000),
        },
        upsert: true,
        primaryColumn: 'path',
        returnData: false,
    });
    await databaseService.execute({
        ...insertFile,
        env: getDatabaseEnv(normalizedEnv),
    });

    return uploadSignedUrl;
};

export const copy = async (
    access: StorageAccess,
    source: string,
    destination: string,
    options: StorageCopyMoveOptions = {},
    env: StorageEnv = 'current'
) => {
    const normalizedAccess = normalizeStorageAccess(access);
    const normalizedEnv = normalizeStorageEnv(env);
    const disk = getDisk(normalizedAccess, normalizedEnv);

    await assertFileExists(normalizedAccess, source, normalizedEnv);
    if (!options.overwrite) {
        await assertFileDoesNotExist(normalizedAccess, destination, normalizedEnv);
    }

    await disk.copy(source, destination, options);

    const metadata = await disk.getMetaData(destination);
    const upsertQuery = databaseService.getInsertQuery({
        schema: 'storage',
        table: ACCESS_TABLE_NAME[normalizedAccess],
        data: {
            ...getFileBaseData(destination),
            size: metadata.contentLength,
            type: metadata.contentType,
        },
        primaryColumn: 'path',
        returnData: true,
        upsert: true,
    });
    const result = await databaseService.execute({
        ...upsertQuery,
        env: getDatabaseEnv(normalizedEnv),
    });

    return result[0];
};

export const move = async (
    access: StorageAccess,
    source: string,
    destination: string,
    options: StorageCopyMoveOptions = {},
    env: StorageEnv = 'current'
) => {
    const normalizedAccess = normalizeStorageAccess(access);
    const normalizedEnv = normalizeStorageEnv(env);
    const disk = getDisk(normalizedAccess, normalizedEnv);
    const overwrite = Boolean(options.overwrite);
    let usedCopyFallback = false;

    await assertFileExists(normalizedAccess, source, normalizedEnv);
    if (!overwrite) {
        await assertFileDoesNotExist(normalizedAccess, destination, normalizedEnv);
    }

    try {
        await disk.move(source, destination, options);
    } catch (error) {
        if (!isUnsupportedOperationError(error)) throw error;
        if (overwrite) throw new StorageUnsupportedOperationError();
        await disk.copy(source, destination, options);
        usedCopyFallback = true;
    }

    try {
        const result = await updateMovedFileInDatabase(
            normalizedAccess,
            source,
            destination,
            overwrite,
            normalizedEnv
        );
        if (usedCopyFallback) {
            await disk.delete(source);
        }
        return result;
    } catch (error) {
        if (usedCopyFallback) {
            try {
                await disk.delete(destination);
            } catch (_cleanupError) {}
        }
        throw error;
    }
};

export const deletePath = async (access: StorageAccess, path: string, env: StorageEnv = 'current') => {
    const normalizedAccess = normalizeStorageAccess(access);
    const normalizedEnv = normalizeStorageEnv(env);
    const disk = getDisk(normalizedAccess, normalizedEnv);

    await assertFileExists(normalizedAccess, path, normalizedEnv);

    await disk.delete(path);

    const normalizedPath = normalizePath(path);
    const deleteQuery = databaseService.getDeleteQuery({
        schema: 'storage',
        table: ACCESS_TABLE_NAME[normalizedAccess],
        filters: {
            link: '$and',
            conditions: [{ field: 'path', operator: '$eq', value: normalizedPath }],
        },
    });
    await databaseService.execute({
        ...deleteQuery,
        env: getDatabaseEnv(normalizedEnv),
    });
};

const driverInstances = new Map<string, DriverContract>();

function getDriver(access: StorageAccess, env: StorageEnv = 'current') {
    const normalizedAccess = normalizeStorageAccess(access);
    const normalizedEnv = normalizeStorageEnv(env);
    const cacheKey = `${normalizedEnv}:${normalizedAccess}`;

    if (driverInstances.has(cacheKey)) return driverInstances.get(cacheKey);

    const runtimeConfig = resolveStorageRuntimeConfig(normalizedEnv);
    if (!runtimeConfig.integration) return null;
    if (!runtimeConfig.connectionId && runtimeConfig.integration !== 'weweb-storage') return null;

    const connection = runtimeConfig.connectionId ? CONNECTIONS[runtimeConfig.connectionId] : null;
    if (runtimeConfig.connectionId && !connection) return null;

    const resolvedConnectionConfig = (
        connection
            ? resolveConnectionConfig(connection.config, {
                  env: normalizedEnv,
              })
            : {}
    ) as ConnectionConfig;

    const storageDriverFactory = getStorageDriver(runtimeConfig.integration);
    if (!storageDriverFactory) return null;
    const driver = storageDriverFactory(normalizedAccess, resolvedConnectionConfig, runtimeConfig);

    if (!driver) return null;

    driverInstances.set(cacheKey, driver);
    return driver;
}

export function getDisk(access: StorageAccess, env: StorageEnv = 'current') {
    const driver = getDriver(access, env);
    if (!driver) throw new Error('No storage driver configured');
    return new Disk(driver);
}

export default {
    ACCESS_TABLE_NAME,
    normalizePath,
    normalizeStorageAccess,
    normalizeStorageEnv,
    getFileBaseData,
    get,
    getBytes,
    put,
    getSignedUrl,
    getSignedUploadUrl,
    copy,
    move,
    delete: deletePath,
    getDisk,
};
