import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { HTTPException } from 'hono/http-exception';
import { registerRoutes } from '../routes/index.js';
import { getCorsOrigin } from './config.core.js';
import { SecurityCheckError } from './errors.core.js';
import { logEndpoint } from './logger.core.ts';
import '../integrations/index.ts';

const basePath = process.env.LAMBDA_INVOKE_MODE === 'STREAM' ? '/api/stream' : '/api';
const app = new Hono().basePath(basePath);

const isEditor = process.env.ENV === 'editor';

app.onError((err, c) => {
    console.error(err);

    if (err instanceof SecurityCheckError) {
        return c.json(err.data, err.status);
    }

    if (err instanceof HTTPException) {
        return c.json({ message: err.message }, err.status);
    }

    return c.json({ message: 'Internal Server Error' }, 500);
});

app.use(async (c, next) => {
    c.set('_startTime', Date.now());
    c.set('_requestId', Math.random().toString(36).substring(2, 15));

    await next();

    logEndpoint(c);
});
app.use(
    '*',
    cors({
        origin: getCorsOrigin,
        allowHeaders: [
            'Content-Type',
            'Authorization',
            'X-API-Key',
            'Cookie',
            'ww-socket-id',
            'ww-editor-user-id',
            'ww-editor-env',
            'ww-debug',
            'ww-editor-test',
            'ww-editor-action-id',
            'ww-editor-previous-results',
        ],
        allowMethods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
        exposeHeaders: ['Content-Length'],
        credentials: true,
    })
);

registerRoutes(app);

export default app;
