/* eslint-disable no-new-func */

const AsyncFunction = (async function(){}).constructor;

function compileCode(code) {
  return new Function('context', 'wwFormulas', code);
}

function compileCodeAsync(code) {
  return new AsyncFunction('context', 'wwFormulas', code);
}

export { compileCode, compileCodeAsync }; 