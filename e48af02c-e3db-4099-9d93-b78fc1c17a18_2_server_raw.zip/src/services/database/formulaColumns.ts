import type { IncludeConfig } from './queryBuilder.ts';
import { isFormulaBinding } from '../tmp/formulas/utils.js';
import { getValue } from '../tmp/utils/input.js';

type FormulaBindingLike = {
    __wwtype: string;
    code: string;
    [key: string]: unknown;
};

type FormulaColumnsConfig = {
    [key: string]: FormulaBindingLike | FormulaColumnsConfig;
};

type ColumnModeArray = {
    $mode: 'array';
    field: string;
};

type ColumnNode = true | '*' | ColumnModeArray | FormulaBindingLike | AliasedColumn | ColumnMap;

type ColumnMap = {
    '*'?: true;
    [key: string]: ColumnNode | true | undefined;
};

type AliasedColumn = {
    $alias: string;
    $value: ColumnNode;
};

type Scope = {
    schema?: string;
    table?: string;
};

type PrepareFormulaColumnsOptions = Scope & {
    includes?: IncludeConfig[];
};

type PreparedFormulaColumns = {
    hasFormulaColumns: boolean;
    materializedColumns: unknown;
    normalizedColumns: unknown;
};

type FormulaExecutionContext = Record<string, unknown>;

function isPlainObject(value: unknown): value is Record<string, unknown> {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isAliasedColumn(value: unknown): value is AliasedColumn {
    return isPlainObject(value) && Object.hasOwn(value, '$alias') && Object.hasOwn(value, '$value');
}

function isFormulaBindingValue(value: unknown): value is FormulaBindingLike {
    return isPlainObject(value) && typeof value.__wwtype === 'string' && typeof value.code === 'string';
}

function isArrayMode(value: unknown): value is ColumnModeArray {
    return isPlainObject(value) && value.$mode === 'array';
}

function extractAliasAndValue(value: unknown): { alias: string | null; actualValue: unknown } {
    if (isAliasedColumn(value)) {
        return { alias: value.$alias, actualValue: value.$value };
    }

    return { alias: null, actualValue: value };
}

function isFormulaFieldPublicFileUrlColumn(key: string, actualValue: unknown, scope: Scope) {
    return (
        key === 'url' &&
        actualValue === true &&
        scope?.schema === 'storage' &&
        scope?.table === 'publicFiles'
    );
}

function buildContextRowAccessExpression(path: string[]) {
    if (!path.length) {
        return 'context.row';
    }

    return `context.row${path.map(segment => `[${JSON.stringify(segment)}]`).join('')}`;
}

function createFormulaFieldPublicFileUrlColumn(contextPath: string[]): FormulaBindingLike {
    return {
        __wwtype: 'f',
        code: `wwFormulas.getStorageUrl(${buildContextRowAccessExpression(contextPath)}.path, 'public')`,
    };
}

function getFormulaFieldColumnsForScope(scope: Scope, contextPath: string[]): ColumnMap {
    if (scope?.schema === 'storage' && scope?.table === 'publicFiles') {
        return {
            url: createFormulaFieldPublicFileUrlColumn(contextPath),
        };
    }

    return {};
}

function createAllColumnsNodeForScope(scope: Scope, contextPath: string[]): ColumnNode {
    const formulaFieldColumns = getFormulaFieldColumnsForScope(scope, contextPath);

    if (!Object.keys(formulaFieldColumns).length) {
        return '*';
    }

    return {
        '*': true,
        ...formulaFieldColumns,
    };
}

function cloneValue<T>(value: T): T {
    if (Array.isArray(value)) {
        return value.map(entry => cloneValue(entry)) as T;
    }

    if (!isPlainObject(value)) {
        return value;
    }

    const result: Record<string, unknown> = {};
    for (const [key, entry] of Object.entries(value)) {
        result[key] = cloneValue(entry);
    }
    return result as T;
}

function normalizeColumnsForScope(
    columns: unknown,
    scope: Scope,
    includeMap: Map<string, Scope>,
    path: string[] = [],
    contextPath: string[] = []
): unknown {
    if (columns === '*') {
        return createAllColumnsNodeForScope(scope, contextPath);
    }

    if (!isPlainObject(columns) || isArrayMode(columns)) {
        return columns;
    }

    const result: ColumnMap = {};

    for (const [key, rawValue] of Object.entries(columns)) {
        const { alias, actualValue } = extractAliasAndValue(rawValue);
        const nextPath = [...path, key];
        const nextContextPath = [...contextPath, alias || key];
        let nextValue = actualValue;

        if (isFormulaFieldPublicFileUrlColumn(key, actualValue, scope)) {
            nextValue = createFormulaFieldPublicFileUrlColumn(contextPath);
        } else if (actualValue === '*') {
            const nextScope = includeMap.get(nextPath.join('.')) || scope;
            nextValue = createAllColumnsNodeForScope(nextScope, nextContextPath);
        } else if (isPlainObject(actualValue) && !isFormulaBindingValue(actualValue) && !isArrayMode(actualValue)) {
            const nextScope = includeMap.get(nextPath.join('.')) || scope;
            nextValue = normalizeColumnsForScope(actualValue, nextScope, includeMap, nextPath, nextContextPath);
        }

        result[key] = alias ? { $alias: alias, $value: nextValue as ColumnNode } : (nextValue as ColumnNode);
    }

    return result;
}

function normalizeFormulaFieldColumns(columns: unknown, options: PrepareFormulaColumnsOptions = {}): unknown {
    const includeMap = new Map<string, Scope>();

    for (const include of options.includes || []) {
        const pathKey = include.path?.join('.') || include.alias;
        if (!pathKey) continue;

        includeMap.set(pathKey, {
            schema: include.schema || 'public',
            table: include.table,
        });
    }

    return normalizeColumnsForScope(
        columns,
        {
            schema: options.schema || 'public',
            table: options.table,
        },
        includeMap
    );
}

function createMergedContainer(value: unknown): ColumnMap {
    if (value === '*') {
        return { '*': true };
    }

    if (isPlainObject(value) && !isFormulaBindingValue(value)) {
        return cloneValue(value as ColumnMap);
    }

    return {};
}

function mergeFormulaColumnsNode(columnValue: unknown, formulaValue: unknown): ColumnNode {
    if (isFormulaBindingValue(formulaValue)) {
        return cloneValue(formulaValue);
    }

    if (!isPlainObject(formulaValue)) {
        return cloneValue(columnValue as ColumnNode);
    }

    const { alias, actualValue } = extractAliasAndValue(columnValue);
    const mergedValue = createMergedContainer(actualValue);

    for (const [key, value] of Object.entries(formulaValue)) {
        mergedValue[key] = mergeFormulaColumnsNode(mergedValue[key], value);
    }

    return alias ? { $alias: alias, $value: mergedValue } : mergedValue;
}

function mergeFormulaColumnsIntoColumns(columns: unknown, formulaColumns: unknown): unknown {
    if (!isPlainObject(formulaColumns) || !Object.keys(formulaColumns).length) {
        return columns;
    }

    const baseConfig = columns === '*' || !isPlainObject(columns) ? {} : cloneValue(columns as ColumnMap);

    for (const [key, value] of Object.entries(formulaColumns)) {
        baseConfig[key] = mergeFormulaColumnsNode(baseConfig[key], value);
    }

    if (columns === '*' || columns === undefined || columns === null) {
        baseConfig['*'] = true;
    }

    return baseConfig;
}

function hasFormulaColumns(value: unknown): boolean {
    if (!isPlainObject(value)) {
        return false;
    }

    if (isFormulaBindingValue(value)) {
        return true;
    }

    if (isAliasedColumn(value)) {
        return hasFormulaColumns(value.$value);
    }

    if (isArrayMode(value)) {
        return false;
    }

    for (const [key, entry] of Object.entries(value)) {
        if (key.startsWith('$')) continue;
        if (hasFormulaColumns(entry)) {
            return true;
        }
    }

    return false;
}

function buildMaterializedNode(node: unknown): unknown {
    const { alias, actualValue } = extractAliasAndValue(node);

    if (isFormulaBindingValue(actualValue)) {
        return undefined;
    }

    let materializedValue = actualValue;

    if (isPlainObject(actualValue) && !isArrayMode(actualValue)) {
        materializedValue = buildMaterializedObject(actualValue, hasFormulaColumns(actualValue));
    }

    if (alias) {
        return { $alias: alias, $value: materializedValue };
    }

    return materializedValue;
}

function buildMaterializedObject(columns: unknown, includeAllColumns = false): ColumnMap {
    const materialized: ColumnMap = includeAllColumns ? { '*': true } : {};

    for (const [key, value] of Object.entries(columns || {})) {
        if (key.startsWith('$') || key === '*') continue;

        const materializedValue = buildMaterializedNode(value);
        if (materializedValue !== undefined) {
            materialized[key] = materializedValue as ColumnNode;
        }
    }

    return materialized;
}

function pickValue(container: unknown, key: string, outputKey: string) {
    if (!isPlainObject(container) && !Array.isArray(container)) {
        return undefined;
    }

    if (outputKey !== key && Object.hasOwn(container, outputKey)) {
        return container[outputKey];
    }

    return container[key];
}

function cloneScopedContainer(value: unknown): Record<string, unknown> | unknown[] {
    if (Array.isArray(value)) {
        return [...value];
    }

    if (isPlainObject(value)) {
        return { ...value };
    }

    return {};
}

function replaceScopedValue(row: unknown, path: string[], value: unknown): unknown {
    if (!path.length) {
        return value;
    }

    const [segment, ...rest] = path;
    const clone = cloneScopedContainer(row);
    const currentValue = isPlainObject(row) ? row[segment] : undefined;

    if (!rest.length) {
        clone[segment] = value;
        return clone;
    }

    clone[segment] = replaceScopedValue(currentValue, rest, value);
    return clone;
}

function evaluateFormulaColumn(
    formula: FormulaBindingLike,
    context: FormulaExecutionContext,
    row: unknown,
    path: string[]
) {
    try {
        return getValue(formula, {
            ...context,
            row,
        });
    } catch (error) {
        throw new Error(`Failed to evaluate formula column "${path.join('.')}"`, { cause: error });
    }
}

function projectObject(
    columns: unknown,
    current: unknown,
    scopedRow: unknown,
    context: FormulaExecutionContext,
    path: string[] = []
): unknown {
    if (columns === '*' || columns === true || !isPlainObject(columns) || isArrayMode(columns)) {
        return current;
    }

    const result: Record<string, unknown> =
        columns['*'] === true && isPlainObject(current) ? { ...current } : {};

    for (const [key, rawValue] of Object.entries(columns)) {
        if (key.startsWith('$') || key === '*') continue;

        const { alias, actualValue } = extractAliasAndValue(rawValue);
        const outputKey = alias || key;
        const sourceValue = pickValue(current, key, outputKey);
        const nextPath = [...path, outputKey];

        if (isFormulaBindingValue(actualValue)) {
            result[outputKey] = evaluateFormulaColumn(actualValue, context, scopedRow, nextPath);
            continue;
        }

        if (actualValue === true || actualValue === '*' || isArrayMode(actualValue)) {
            result[outputKey] = sourceValue;
            continue;
        }

        if (Array.isArray(sourceValue)) {
            result[outputKey] = sourceValue.map(item =>
                projectObject(actualValue, item, replaceScopedValue(scopedRow, nextPath, item), context, nextPath)
            );
            continue;
        }

        if (sourceValue === null || sourceValue === undefined) {
            result[outputKey] = sourceValue;
            continue;
        }

        result[outputKey] = projectObject(
            actualValue,
            sourceValue,
            replaceScopedValue(scopedRow, nextPath, sourceValue),
            context,
            nextPath
        );
    }

    return result;
}

function applyFormulaColumns(rows: unknown, columns: unknown, context: FormulaExecutionContext): unknown {
    if (!Array.isArray(rows) || !hasFormulaColumns(columns)) {
        return rows;
    }

    return rows.map(row => projectObject(columns, row, row, context));
}

function prepareFormulaColumns(
    columns: unknown,
    formulaColumns: FormulaColumnsConfig | undefined,
    options: PrepareFormulaColumnsOptions = {}
): PreparedFormulaColumns {
    const normalizedColumns = mergeFormulaColumnsIntoColumns(
        normalizeFormulaFieldColumns(columns, options),
        formulaColumns
    );
    const formulaEnabled = hasFormulaColumns(normalizedColumns);

    if (!formulaEnabled || !isPlainObject(normalizedColumns)) {
        return {
            hasFormulaColumns: formulaEnabled,
            materializedColumns: normalizedColumns,
            normalizedColumns,
        };
    }

    return {
        hasFormulaColumns: true,
        materializedColumns: buildMaterializedObject(normalizedColumns, true),
        normalizedColumns,
    };
}

function resolveWorkflowColumns(rawColumns: unknown, context: FormulaExecutionContext): unknown {
    if (rawColumns === null || rawColumns === undefined) {
        return rawColumns;
    }

    if (isFormulaBinding(rawColumns)) {
        return getValue(rawColumns, context);
    }

    if (Array.isArray(rawColumns)) {
        return rawColumns.map(value => resolveWorkflowColumns(value, context));
    }

    if (!isPlainObject(rawColumns)) {
        return rawColumns;
    }

    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(rawColumns)) {
        result[key] = resolveWorkflowColumns(value, context);
    }

    return result;
}

function resolveWorkflowFormulaColumns(rawFormulaColumns: unknown): unknown {
    if (rawFormulaColumns === null || rawFormulaColumns === undefined) {
        return rawFormulaColumns;
    }

    if (isFormulaBindingValue(rawFormulaColumns)) {
        return rawFormulaColumns;
    }

    if (Array.isArray(rawFormulaColumns)) {
        return rawFormulaColumns.map(value => resolveWorkflowFormulaColumns(value));
    }

    if (!isPlainObject(rawFormulaColumns)) {
        return rawFormulaColumns;
    }

    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(rawFormulaColumns)) {
        result[key] = resolveWorkflowFormulaColumns(value);
    }

    return result;
}

export { applyFormulaColumns, prepareFormulaColumns, resolveWorkflowColumns, resolveWorkflowFormulaColumns };
