import fs from 'node:fs';
import path from 'node:path';
import { parseEnv } from 'node:util';

export type RuntimeEnv = 'current' | 'editor' | 'staging' | 'production';
type ParsedRuntimeEnv = Exclude<RuntimeEnv, 'current'>;
type RuntimeEnvValues = Record<string, string | undefined>;
type ParsedRuntimeEnvMap = Record<ParsedRuntimeEnv, RuntimeEnvValues>;

const PARSED_RUNTIME_ENVS: ParsedRuntimeEnv[] = ['editor', 'staging', 'production'];

let parsedEnvMap: ParsedRuntimeEnvMap | null = null;

function parseEnvFile(filePath: string): RuntimeEnvValues {
    try {
        const content = fs.readFileSync(filePath, 'utf-8');
        const parsed = parseEnv(content);
        const values: RuntimeEnvValues = {};
        for (const key in parsed) {
            values[key] = parsed[key];
        }
        return values;
    } catch (_error) {
        return {};
    }
}

export function parseStoredEnvs(): ParsedRuntimeEnvMap {
    if (parsedEnvMap) return parsedEnvMap;

    parsedEnvMap = {
        editor: {},
        staging: {},
        production: {},
    };

    for (const env of PARSED_RUNTIME_ENVS) {
        const envFilePath = path.resolve(process.cwd(), `.env.${env}`);
        parsedEnvMap[env] = parseEnvFile(envFilePath);
    }

    return parsedEnvMap;
}

function getEnvValues(env: RuntimeEnv = 'current'): RuntimeEnvValues {
    if (env === 'current') return process.env;
    return parseStoredEnvs()[env];
}

export function getEnv(key: string, env: RuntimeEnv = 'current'): string | undefined {
    return getEnvValues(env)[key] ?? process.env[key];
}

export default {
    parseStoredEnvs,
    getEnv,
};
