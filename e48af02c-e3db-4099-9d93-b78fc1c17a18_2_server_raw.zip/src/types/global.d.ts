import type { Context as HonoContext } from 'hono';

declare global {
    type ActionParams = {
        args: { [key: string]: any | undefined };
    };
    type ActionContext = {
        connection?: ConnectionConfig;
        honoContext: HonoContext;
    };
    type ConnectionConfig = {
        [key: string]: string | undefined | any;
    };
    type StorageRuntimeConfig = {
        env: 'current' | 'editor' | 'staging' | 'production';
        integration?: string;
        connectionId?: string;
        privateBucket?: string;
        publicBucket?: string;
        privatePrefix?: string;
        publicPrefix?: string;
        appUrl?: string;
        proxyUrl?: string;
        projectId?: string;
    };
    type TableConfig = {
        [key: string]: any | undefined;
    };
    type ViewConfig = {
        [key: string]: any | undefined;
    };
}

export {};
