import { HTTPException } from 'hono/http-exception';

export function throwDbError(err) {
    throw new HTTPException(500, {
        message: err.message,
        cause: {
            code: err.code,
            detail: err.detail,
            constraint: err.constraint,
            table: err.table,
            schema: err.schema,
        },
    });
}
