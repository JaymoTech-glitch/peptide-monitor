import triggerCore from '../core/trigger.core.js';
import hooksCore from '../core/hooks.core.js';
import { getSignedCookie, deleteCookie } from 'hono/cookie';
import wewebService from '../services/weweb.service.js';
import { resolveConnection } from '../services/connection.service.js';
import CONNECTIONS from '../data/connections.json' with { type: 'json' };

export const sessionMiddleware = async (c, next) => {
    const authIntegration = process.env.AUTH_INTEGRATION;
    const authConnectionId = process.env.AUTH_CONNECTION_ID;

    if (authIntegration) {
        const connection = authConnectionId ? resolveConnection(CONNECTIONS[authConnectionId]) : null;
        const session = await getSignedCookie(c, process.env.AUTH_SECRET, 'ww-app-session', 'secure');

        if (session) {
            c.set('session', JSON.parse(session));
        }
        try {
            await hooksCore.execute(c, `auth-refresh/integration:${authIntegration}`, {
                session: c.get('session'),
                connection,
            });
        } catch (error) {
            c.set('user', null);
            c.set('session', null);
            await deleteCookie(c, 'ww-app-session', { 
                prefix: 'secure', 
                path: '/',
                secure: true,
                httpOnly: true,
                sameSite: 'None'
            });
        }
    }

    return next();
};
